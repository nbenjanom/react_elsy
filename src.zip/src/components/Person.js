import React from 'react';

import Slider from "rc-slider";
import 'rc-slider/assets/index.css';

class Person extends React.Component {
    render() {
        return (
            <div style = {{fontSize : 100 , color: "black" }} className="box col-md-2 col-6">
                <i className="material-icons">
                    directions_walk
                </i>
                <p>
                    {this.props.step}
                </p>
                <button>+</button>
                <Slider min={0} max={50000}  onChange={(val) => this.props.onChangeFn(val)} />
            </div>

        );
    }
}

export default Person;