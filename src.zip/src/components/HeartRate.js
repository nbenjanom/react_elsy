import React from "react";
import Slider from "rc-slider";
import 'rc-slider/assets/index.css';

class HeartRate extends React.Component{
    render() {
        return (
            <div style = {{fontSize : 100 , color: "red" }} className="boxEven col-md-2 col-6">
                <i className="material-icons">
                    favorite
                </i>
                <p>{this.props.heart}</p>
                
                <Slider min={80} max={180} onChange={(val) => this.props.onChangeFn(val)} />
            </div>

        );
    }
}

export default HeartRate;