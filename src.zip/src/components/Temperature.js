import React from 'react';

import Slider from "rc-slider";
import 'rc-slider/assets/index.css';

class Temperature extends React.Component {
    render() {
        return (
            <div style = {{fontSize : 100 , color: "black" }} className="boxEven col-md-2 col-6">
                <i className="material-icons">
                    wb_sunny
                </i>
                <p>
                    {this.props.temp}
                </p>
                <Slider min={-20} max={40} onChange={(val) => this.props.onChangeFn(val)} />
            </div>
        );
    }
}

export default Temperature;