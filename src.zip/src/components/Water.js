import React from 'react';



class Water extends React.Component {
    render() {
        return (
            <div style = {{fontSize : 100 , color: "black" }} className="box col-md-2 col-6">
                <i className="material-icons">
                    local_drink
                </i>
                <p>
                    {this.props.waterFn}
                </p>
            </div>
        );
    }
}

export default Water;